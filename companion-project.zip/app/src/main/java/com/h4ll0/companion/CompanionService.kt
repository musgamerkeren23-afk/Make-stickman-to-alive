package com.h4ll0.companion

import android.app.*
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

class CompanionService : Service() {
    private lateinit var wm: WindowManager
    private var view: StickView? = null
    private val handler = Handler(Looper.myLooper()!!)
    private var lastApp = ""
    private var lastTouch = System.currentTimeMillis()

    private val idleLines = listOf("Halo! 👋", "Lagi apa nih?", "Aku di sini terus lho", "...", "Hehe")
    private val tapLines = listOf("Hehe~", "Jangan colek-colek!", "Hai!", "Woy!")
    private val surpriseLines = listOf("Eh, pindah ke mana?!", "Woi tunggu!", "Kok ditinggal...")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(2, notif())
        addView()
        pollLoop()
    }

    private fun notif(): Notification {
        val ch = "companion"
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(ch, "Teman Digital", NotificationManager.IMPORTANCE_MIN)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c)
        }
        return NotificationCompat.Builder(this, ch)
            .setContentTitle("Teman Digital aktif")
            .setContentText("Tap stickman buat nyapa dia")
            .setSmallIcon(android.R.drawable.sym_def_app_icon)
            .setOngoing(true).build()
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun addView() {
        val sv = StickView(this)
        val size = (130 * resources.displayMetrics.density).toInt()
        val p = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = 40; p.y = 300
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        sv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - dx).toInt(); p.y = sy + (e.rawY - dy).toInt()
                    if (max(abs(e.rawX - dx), abs(e.rawY - dy)) > 12) moved = true
                    wm.updateViewLayout(sv, p); true
                }
                MotionEvent.ACTION_UP -> {
                    lastTouch = System.currentTimeMillis()
                    if (!moved) react(sv, Mood.HAPPY, tapLines.random())
                    true
                }
                else -> false
            }
        }
        wm.addView(sv, p)
        view = sv
    }

    private fun react(sv: StickView, m: Mood, line: String? = null, back: Mood = Mood.IDLE, holdMs: Long = 1800) {
        sv.mood = m
        line?.let { sv.say(it) }
        sv.postInvalidate()
        handler.postDelayed({ sv.mood = back; sv.postInvalidate() }, holdMs)
    }

    private fun pollLoop() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                val sv = view
                if (sv != null) {
                    val now = System.currentTimeMillis()
                    val idleMs = now - lastTouch
                    if (idleMs > 90_000 && sv.mood == Mood.IDLE) { sv.mood = Mood.SLEEPY; sv.postInvalidate() }
                    else if (idleMs < 90_000 && sv.mood == Mood.SLEEPY) { sv.mood = Mood.IDLE; sv.postInvalidate() }
                    if (Random.nextInt(100) < 4 && sv.mood == Mood.IDLE) sv.say(idleLines.random())
                    checkForegroundApp(sv)
                }
                handler.postDelayed(this, 3000)
            }
        }, 3000)
    }

    private fun checkForegroundApp(sv: StickView) {
        try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis(); val begin = end - 10_000
            val events = usm.queryEvents(begin, end)
            var current = lastApp
            val ev = android.app.usage.UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(ev)
                if (ev.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND) current = ev.packageName
            }
            if (current.isNotEmpty() && lastApp.isNotEmpty() && current != lastApp) {
                react(sv, Mood.SURPRISED, surpriseLines.random())
            }
            lastApp = current
        } catch (_: Exception) { /* izin usage access belum aktif */ }
    }

    override fun onDestroy() {
        super.onDestroy()
        view?.let { runCatching { wm.removeView(it) } }
        handler.removeCallbacksAndMessages(null)
    }
}
