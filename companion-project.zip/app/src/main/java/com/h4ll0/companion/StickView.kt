package com.h4ll0.companion

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.max
import kotlin.random.Random

enum class Mood { IDLE, HAPPY, SLEEPY, SURPRISED, TALK }

class StickView(c: Context) : View(c) {
    var mood = Mood.IDLE
    private var blink = false
    private var bubble: String? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 8f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1C1414") }
    private val bubbleBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E0262E"); style = Paint.Style.STROKE; strokeWidth = 3f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 24f; textAlign = Paint.Align.CENTER }

    init {
        postDelayed(object : Runnable {
            override fun run() { blink = true; postInvalidate(); postDelayed({ blink = false; postInvalidate() }, 120); postDelayed(this, Random.nextLong(2000, 5000)) }
        }, 2000)
    }

    fun say(text: String, ms: Long = 2200) {
        bubble = text; postInvalidate()
        postDelayed({ bubble = null; postInvalidate() }, ms)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h * 0.55f; val r = h * 0.22f
        bubble?.let { msg ->
            val bw = max(txt.measureText(msg) + 40f, 80f)
            val bx = cx - bw / 2; val by = cy - r - 70f
            val rect = RectF(bx, by, bx + bw, by + 46f)
            cv.drawRoundRect(rect, 16f, 16f, bubblePaint)
            cv.drawRoundRect(rect, 16f, 16f, bubbleBorder)
            cv.drawText(msg, cx, by + 30f, txt)
        }
        cv.drawCircle(cx, cy, r, paint)
        val eyeOffset = when (mood) { Mood.SURPRISED -> r * 0.4f; else -> r * 0.3f }
        val eyeY = cy - r * 0.15f
        if (blink && mood != Mood.SLEEPY) {
            cv.drawLine(cx - eyeOffset - 8f, eyeY, cx - eyeOffset + 8f, eyeY, paint)
            cv.drawLine(cx + eyeOffset - 8f, eyeY, cx + eyeOffset + 8f, eyeY, paint)
        } else when (mood) {
            Mood.SLEEPY -> {
                cv.drawLine(cx - eyeOffset - 8f, eyeY, cx - eyeOffset + 8f, eyeY, paint)
                cv.drawLine(cx + eyeOffset - 8f, eyeY, cx + eyeOffset + 8f, eyeY, paint)
            }
            Mood.SURPRISED -> {
                cv.drawCircle(cx - eyeOffset, eyeY, 7f, fill)
                cv.drawCircle(cx + eyeOffset, eyeY, 7f, fill)
            }
            Mood.HAPPY -> {
                cv.drawArc(RectF(cx - eyeOffset - 8f, eyeY - 8f, cx - eyeOffset + 8f, eyeY + 10f), 200f, 140f, false, paint)
                cv.drawArc(RectF(cx + eyeOffset - 8f, eyeY - 8f, cx + eyeOffset + 8f, eyeY + 10f), 200f, 140f, false, paint)
            }
            else -> {
                cv.drawCircle(cx - eyeOffset, eyeY, 5f, fill)
                cv.drawCircle(cx + eyeOffset, eyeY, 5f, fill)
            }
        }
        val mouthY = cy + r * 0.35f
        when (mood) {
            Mood.HAPPY -> cv.drawArc(RectF(cx - r * 0.4f, mouthY - 14f, cx + r * 0.4f, mouthY + 14f), 10f, 160f, false, paint)
            Mood.SURPRISED -> cv.drawCircle(cx, mouthY, 9f, fill)
            Mood.SLEEPY -> cv.drawLine(cx - 10f, mouthY, cx + 10f, mouthY, paint)
            Mood.TALK -> cv.drawOval(RectF(cx - 10f, mouthY - 8f, cx + 10f, mouthY + 8f), fill)
            Mood.IDLE -> cv.drawLine(cx - 12f, mouthY, cx + 12f, mouthY, paint)
        }
        val neck = cy + r
        val hip = neck + r * 1.4f
        cv.drawLine(cx, neck, cx, hip, paint)
        val armY = neck + r * 0.5f
        val armSwing = if (mood == Mood.HAPPY) r * 0.5f else r * 0.35f
        cv.drawLine(cx, armY, cx - r * 0.9f, armY - armSwing, paint)
        cv.drawLine(cx, armY, cx + r * 0.9f, armY - armSwing, paint)
        cv.drawLine(cx, hip, cx - r * 0.6f, hip + r * 1.1f, paint)
        cv.drawLine(cx, hip, cx + r * 0.6f, hip + r * 1.1f, paint)
    }
}
