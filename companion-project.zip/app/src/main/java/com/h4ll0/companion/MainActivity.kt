package com.h4ll0.companion

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Red = Color(0xFFE0262E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Color(0xFF0D0A0A), surface = Color(0xFF191212))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }

    fun hasOverlay() = Settings.canDrawOverlays(this)
    fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }
    fun start() {
        val i = Intent(this, CompanionService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this, i) else startService(i)
    }
    fun stop() = stopService(Intent(this, CompanionService::class.java))
}

@Composable
fun App() {
    val a = androidx.compose.ui.platform.LocalContext.current as MainActivity
    var overlayOk by remember { mutableStateOf(a.hasOverlay()) }
    var usageOk by remember { mutableStateOf(a.hasUsage()) }
    var running by remember { mutableStateOf(false) }
    val lOverlay = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { overlayOk = a.hasOverlay() }
    val lUsage = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { usageOk = a.hasUsage() }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Teman Digital", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Red)
        Spacer(Modifier.height(6.dp))
        Text("Stickman melayang di layar HP-mu. Tap dia buat nyapa, dia juga bereaksi sendiri.", color = Color.Gray)
        Spacer(Modifier.height(20.dp))

        if (!overlayOk) {
            Text("1. Izinkan tampil di atas app lain:", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Button({ lOverlay.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))) }) { Text("Buka izin overlay") }
        } else if (!usageOk) {
            Text("2. Izinkan Usage Access (biar dia nyadar pas kamu pindah app, opsional):", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Button({ lUsage.launch(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) { Text("Buka Usage Access") }
            Spacer(Modifier.height(10.dp))
            OutlinedButton({ usageOk = true }) { Text("Lewati, gak penting") }
        } else {
            Text("Semua izin siap ✓", color = Color(0xFF7CFF8C))
            Spacer(Modifier.height(16.dp))
            if (!running) Button({ a.start(); running = true }, Modifier.fillMaxWidth()) { Text("Panggil stickman-nya") }
            else OutlinedButton({ a.stop(); running = false }, Modifier.fillMaxWidth()) { Text("Suruh dia pergi dulu") }
        }
    }
}
